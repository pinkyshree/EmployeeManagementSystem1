//package com.abc.demo;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.context.annotation.AnnotationConfigApplicationContext;
//import org.springframework.stereotype.Component;
//
//@Component
//class Chef
//{
//	Food f;
//	
//	@Autowired
//	public Chef(Food f)//f = new Food();
//	{
//		this.f = f;
//	}
//	
//	
//	public void run()
//	{
//		f.prepareFood();
//	}
//}
//
//@Component
//class Food
//{
//	public void prepareFood()
//	{
//		System.out.println("Chef is preparing gulab jamun!");
//	}
//}
//
//public class Second 
//{
//	public static void main(String[] args) 
//	{
//		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(Config.class);
//		context.getBean(Chef.class).run();
//	
//	}
//}
//package com;


