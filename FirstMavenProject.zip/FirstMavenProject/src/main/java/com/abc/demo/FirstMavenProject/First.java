//package com.abc.demo;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.context.annotation.AnnotationConfigApplicationContext;
//import org.springframework.stereotype.Component;
//
////Dependency Injection
//
////If one java class is dependent on another java class = dependency
//
////One class object injecting inside another class = dependecy injection
//
////Dependency Injection can be achieved in 3 ways:-
//
////1) Field Injection
////2) Constructor Injection
// 3) Setter Injection
//
//@Component
//class Chef
//{
////	Food f = new Food(); Not Recommended
//	
//	@Autowired
//	Food f;// field
//	
//	public void run()
//	{
//		f.prepareFood();
//	}
//}
//
//@Component
//class Food
//{
//	public void prepareFood()
//	{
//		System.out.println("Chef is preparing gulab jamun!");
//	}
//}
//
//public class First 
//{
//	public static void main(String[] args) 
//	{
////		Chef c = new Chef();
////		c.run();
//		
//		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(Config.class);
//		context.getBean(Chef.class).run();
//		
//		
//	}
//}
//package com;


